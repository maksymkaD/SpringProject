package com.example.nosqldbspringbootstarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NosqlDbSpringBootStarterApplicationTests {

    @Test
    void contextLoads() {
    }

}

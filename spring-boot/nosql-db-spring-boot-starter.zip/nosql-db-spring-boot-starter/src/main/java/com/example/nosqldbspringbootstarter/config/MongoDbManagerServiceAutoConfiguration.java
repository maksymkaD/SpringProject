package com.example.nosqldbspringbootstarter.config;

import com.example.nosqldbspringbootstarter.service.MongoDbManagerService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnClass(MongoDbManagerService.class)
public class MongoDbManagerServiceAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public MongoDbManagerService mongoDbManagerService() {
        return new MongoDbManagerService();
    }
}

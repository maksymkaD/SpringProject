package com.example.nosqldbspringbootstarter.service;

import java.util.HashMap;

public interface DbManagerService {
    public void establishDatabaseConnection(HashMap<String, String> props);
}

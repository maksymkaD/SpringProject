package com.example.nosqldbspringbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NosqlDbSpringBootStarterApplication {

    public static void main(String[] args) {
        SpringApplication.run(NosqlDbSpringBootStarterApplication.class, args);
    }

}

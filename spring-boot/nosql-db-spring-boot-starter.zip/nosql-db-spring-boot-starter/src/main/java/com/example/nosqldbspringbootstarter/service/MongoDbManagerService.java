package com.example.nosqldbspringbootstarter.service;

import com.mongodb.client.MongoClient;

import java.util.HashMap;

public class MongoDbManagerService implements DbManagerService {

    @Override
    public void establishDatabaseConnection(HashMap<String, String> props) {
        String connectionString = props.get("connection-string");
        System.out.println("Established connection to mongodb database");
    }
}

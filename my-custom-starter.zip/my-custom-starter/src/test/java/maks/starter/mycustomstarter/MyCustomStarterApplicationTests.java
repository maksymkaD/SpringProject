package maks.starter.mycustomstarter;

class MyCustomStarterApplicationTests {

    void contextLoads() {
    }

}

package maks.starter.mycustomstarter;

public class HelloService {
    public void hello() {
        System.out.println("Hello from the default starter");
    }
}

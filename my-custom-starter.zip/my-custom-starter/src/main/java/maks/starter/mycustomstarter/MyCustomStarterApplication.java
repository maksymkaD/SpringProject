package maks.starter.mycustomstarter;

import org.springframework.boot.SpringApplication;

public class MyCustomStarterApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyCustomStarterApplication.class, args);
    }

}

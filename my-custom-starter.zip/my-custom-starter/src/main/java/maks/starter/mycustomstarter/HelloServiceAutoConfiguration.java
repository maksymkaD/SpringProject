package maks.starter.mycustomstarter;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*
HelloServiceAutoConfiguration will run if HelloService class is available in the classpath. ( @ConditionOnClass annotation).
HelloService Bean will be created by Spring Boot if it is not available (@ConditionalOnMissingBean).
If developer defines their own HelloService bean, our customer starter will not create HelloService Bean.
 */

@Configuration
@ConditionalOnClass(HelloService.class)
public class HelloServiceAutoConfiguration {


    //conditional bean creation
    @Bean
    @ConditionalOnMissingBean
    public HelloService helloService(){

        return new HelloService();
    }
}